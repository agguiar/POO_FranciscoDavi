package br.com.ecommerce.util;

import br.com.ecommerce.anotacoes.AuditoriaLogistica;
import java.util.NoSuchElementException;

@AuditoriaLogistica
public class FilaArmazenamento<T> {

    private static class No<E> {

        private E dado;
        private No<E> proximo;

        public No(E dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }

    private No<T> inicio;
    private No<T> fim;
    private int tamanho;

    public FilaArmazenamento() {
        inicio = null;
        fim = null;
        tamanho = 0;
    }

    public void enfileirar(T elemento) {

        No<T> novo = new No<>(elemento);

        if (estaVazia()) {
            inicio = novo;
        } else {
            fim.proximo = novo;
        }

        fim = novo;
        tamanho++;
    }

    public T desenfileirar() {

        if (estaVazia()) {
            throw new NoSuchElementException("A fila esta vazia.");
        }

        T elemento = inicio.dado;
        inicio = inicio.proximo;
        tamanho--;

        if (estaVazia()) {
            fim = null;
        }

        return elemento;
    }

    public int getTamanho() {
        return tamanho;
    }

    public boolean estaVazia() {
        return tamanho == 0;
    }
}