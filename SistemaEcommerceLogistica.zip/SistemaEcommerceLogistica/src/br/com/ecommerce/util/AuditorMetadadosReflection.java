package br.com.ecommerce.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import br.com.ecommerce.anotacoes.AuditoriaLogistica;

public class AuditorMetadadosReflection {

    public static void inspecionarClasse(Class<?> clazz) {

        System.out.println("\n=== AUDITORIA DA CLASSE ===");

        System.out.println("Nome da classe: " + clazz.getName());

        Class<?> superclasse = clazz.getSuperclass();

        if (superclasse != null) {
            System.out.println("Superclasse: " + superclasse.getName());
        }

        if (clazz.isAnnotationPresent(AuditoriaLogistica.class)) {

            AuditoriaLogistica anotacao =
                    clazz.getAnnotation(AuditoriaLogistica.class);

            System.out.println("Anotacao encontrada: @AuditoriaLogistica");
            System.out.println("Nivel de criticidade: "
                    + anotacao.nivelCriticidade());
            System.out.println("Registrar data e hora: "
                    + anotacao.registrarDataHora());

        } else {
            System.out.println("Classe sem anotacao @AuditoriaLogistica");
        }

        System.out.println("\n--- Atributos Declarados ---");

        Field[] atributos = clazz.getDeclaredFields();

        for (Field atributo : atributos) {
            System.out.println("Atributo: " + atributo.getName()
                    + " | Tipo: " + atributo.getType().getSimpleName());
        }

        System.out.println("\n--- Metodos da Classe ---");

        Method[] metodos = clazz.getMethods();

        int contadorMetodos = 0;

        for (Method metodo : metodos) {

            if (metodo.getDeclaringClass() == clazz) {

                System.out.println("Metodo: " + metodo.getName());

                contadorMetodos++;
            }
        }

        System.out.println("Total de metodos da classe: " + contadorMetodos);
    }
}