package br.com.ecommerce.logistica;

import java.util.Date;

import br.com.ecommerce.excecoes.LogisticaException;
import br.com.ecommerce.excecoes.EstoqueInvalidoException;

public class PacoteExpresso extends ItemLogistico {

    private boolean entregaNoMesmoDia;
    private Date dataRegistro;
    private java.sql.Date dataPrevistaEntrega;

    public PacoteExpresso(String codigoEtiqueta, double pesoKg,
                          double cubagemM3, boolean entregaNoMesmoDia)
                          throws LogisticaException {

        super(codigoEtiqueta, pesoKg, cubagemM3);

        if (pesoKg <= 0) {
            throw new EstoqueInvalidoException(
                    "O peso deve ser maior que zero.");
        }

        this.entregaNoMesmoDia = entregaNoMesmoDia;
        this.dataRegistro = new Date();
        this.dataPrevistaEntrega =
                new java.sql.Date(System.currentTimeMillis());
    }

    public PacoteExpresso(String codigoEtiqueta, double pesoKg)
                          throws LogisticaException {

        this(codigoEtiqueta, pesoKg, 0.05, false);
    }

    @Override
    public double calcularFreteBase() {
        double valor = 15.0 + (pesoKg * 5.0)
                + (cubagemM3 * 10.0);

        if (entregaNoMesmoDia) {
            valor += 20.0;
        }

        return valor;
    }

    public boolean isEntregaNoMesmoDia() {
        return entregaNoMesmoDia;
    }

    public Date getDataRegistro() {
        return dataRegistro;
    }

    public java.sql.Date getDataPrevistaEntrega() {
        return dataPrevistaEntrega;
    }

    @Override
    public String toString() {
        return super.toString()
                + ", Entrega no mesmo dia: " + entregaNoMesmoDia
                + ", Frete base: R$ " + calcularFreteBase();
    }
}
