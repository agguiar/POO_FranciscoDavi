package br.com.ecommerce.app;

import static br.com.ecommerce.logistica.StatusRastreio.*;
import static br.com.ecommerce.util.CalculadoraLogistica.*;

import br.com.ecommerce.excecoes.LogisticaException;
import br.com.ecommerce.logistica.PacoteExpresso;
import br.com.ecommerce.logistica.StatusRastreio;
import br.com.ecommerce.util.FilaArmazenamento;

public class DemonstradorBloco2App {

    public static void main(String[] args) {

        System.out.println("=== BLOCO 2 ===");

        FilaArmazenamento<PacoteExpresso> fila =
                new FilaArmazenamento<>();

        try {

            PacoteExpresso pacote1 =
                    new PacoteExpresso("ETQ001", 2.5, 0.1, true);

            PacoteExpresso pacote2 =
                    new PacoteExpresso("ETQ002", 3.0);

            PacoteExpresso pacote3 =
                    new PacoteExpresso("ETQ003", 1.5, 0.08, false);

            fila.enfileirar(pacote1);
            fila.enfileirar(pacote2);
            fila.enfileirar(pacote3);

            System.out.println("Itens na fila: " + fila.getTamanho());

            while (!fila.estaVazia()) {

                PacoteExpresso pacote = fila.desenfileirar();

                double valorBase = pacote.calcularFreteBase();

                double valorFinal =
                        calcularCustoFinal(valorBase, 5.0, 2.5, 1.0);

                StatusRastreio status = EM_TRANSITO;

                String resumo = formatarResumoOperacao(
                        pacote.getCodigoEtiqueta(),
                        status,
                        valorFinal);

                System.out.println(resumo);
                System.out.println("Itens restantes: "
                        + fila.getTamanho());
            }

            System.out.println();

            System.out.println("Status: " + ENTREGUE);
            System.out.println("Prazo: "
                    + ENTREGUE.getPrazoDiasUteis() + " dias");
            System.out.println("Requer assinatura: "
                    + ENTREGUE.isRequerAssinatura());
            System.out.println("Finalizado: "
                    + ENTREGUE.isFinalizado());

        } catch (LogisticaException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}