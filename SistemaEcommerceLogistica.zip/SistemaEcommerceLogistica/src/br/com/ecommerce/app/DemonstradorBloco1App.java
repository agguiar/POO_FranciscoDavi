package br.com.ecommerce.app;

import br.com.ecommerce.excecoes.LogisticaException;
import br.com.ecommerce.excecoes.EstoqueInvalidoException;
import br.com.ecommerce.logistica.ItemLogistico;
import br.com.ecommerce.logistica.PacoteExpresso;

public class DemonstradorBloco1App {

    public static void main(String[] args) {

        System.out.println("=== BLOCO 1 ===");

        try {
            PacoteExpresso pacote =
                    new PacoteExpresso("ETQ001", 2.5, 0.1, true);

            pacote.setDespachado(true);

            System.out.println(pacote);
            System.out.println("Total de itens: "
                    + ItemLogistico.getContadorItens());

        } catch (LogisticaException | EstoqueInvalidoException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        System.out.println();

        try {
            PacoteExpresso pacoteInvalido =
                    new PacoteExpresso("ETQ002", -2.0);

            System.out.println(pacoteInvalido);

        } catch (LogisticaException | EstoqueInvalidoException e) {
            System.out.println("Erro identificado: " + e.getMessage());
        }

        System.out.println();

        try {
            PacoteExpresso pacote =
                    new PacoteExpresso("ETQ", 2.0);

            System.out.println(pacote);

        } catch (LogisticaException | EstoqueInvalidoException e) {
            System.out.println("Erro identificado: " + e.getMessage());
        }

        System.out.println();

        int resultado = demonstrarFinally();

        System.out.println("Valor retornado: " + resultado);

        System.out.println();

        demonstrarTryFinally();
    }

    public static int demonstrarFinally() {

        try {
            System.out.println("Executando bloco try...");
            return 10;

        } finally {
            System.out.println("Executando bloco finally...");
        }
    }

    public static void demonstrarTryFinally() {

        try {
            System.out.println("Iniciando recurso local...");
            System.out.println("Processando operacao...");

        } finally {
            System.out.println("Liberando recurso local...");
        }
    }
}