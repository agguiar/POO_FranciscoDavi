package br.com.ecommerce.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

import br.com.ecommerce.excecoes.LogisticaException;
import br.com.ecommerce.logistica.PacoteExpresso;

public class ProcessadorStreamsApp {

    public static void main(String[] args) {

        System.out.println("=== BLOCO 3 ===");

        List<PacoteExpresso> pacotes = new ArrayList<>();

        try {

            pacotes.add(new PacoteExpresso("ETQ001", 2.5, 0.1, true));
            pacotes.add(new PacoteExpresso("ETQ002", 3.0, 0.05, false));
            pacotes.add(new PacoteExpresso("ETQ003", 1.5, 0.08, true));
            pacotes.add(new PacoteExpresso("ETQ004", 5.0, 0.2, false));
            pacotes.add(new PacoteExpresso("ETQ005", 1.0, 0.05, false));

        } catch (LogisticaException e) {
            System.out.println("Erro: " + e.getMessage());
            return;
        }

        System.out.println("\n--- Ordenacao com Classe Anonima ---");

        Collections.sort(pacotes, new Comparator<PacoteExpresso>() {

            @Override
            public int compare(PacoteExpresso p1, PacoteExpresso p2) {
                return Double.compare(
                        p1.calcularFreteBase(),
                        p2.calcularFreteBase());
            }
        });

        for (PacoteExpresso pacote : pacotes) {
            System.out.println(pacote.getCodigoEtiqueta()
                    + " - R$ " + pacote.calcularFreteBase());
        }

        System.out.println("\n--- Ordenacao com Lambda ---");

        Collections.sort(pacotes, (p1, p2) ->
                Double.compare(
                        p1.calcularFreteBase(),
                        p2.calcularFreteBase()));

        for (PacoteExpresso pacote : pacotes) {
            System.out.println(pacote.getCodigoEtiqueta()
                    + " - R$ " + pacote.calcularFreteBase());
        }

        System.out.println("\n--- Entregas no Mesmo Dia ---");

        List<PacoteExpresso> entregasMesmoDia = pacotes.stream()
                .filter(PacoteExpresso::isEntregaNoMesmoDia)
                .collect(Collectors.toList());

        for (PacoteExpresso pacote : entregasMesmoDia) {
            System.out.println(pacote.getCodigoEtiqueta()
                    + " - R$ " + pacote.calcularFreteBase());
        }

        System.out.println("\n--- Media de Frete ---");

        OptionalDouble media = pacotes.stream()
                .mapToDouble(PacoteExpresso::calcularFreteBase)
                .average();

        if (media.isPresent()) {
            System.out.println("Media: R$ " + media.getAsDouble());
        }

        System.out.println("\n--- Fretes Acima de R$ 40 ---");

        long quantidade = pacotes.stream()
                .filter(p -> p.calcularFreteBase() > 40.0)
                .count();

        System.out.println("Quantidade: " + quantidade);

        System.out.println("\n--- Pacote com Menor Frete ---");

        pacotes.stream()
                .min(Comparator.comparingDouble(
                        PacoteExpresso::calcularFreteBase))
                .ifPresent(p -> System.out.println(
                        p.getCodigoEtiqueta()
                        + " - R$ " + p.calcularFreteBase()));
    }
}