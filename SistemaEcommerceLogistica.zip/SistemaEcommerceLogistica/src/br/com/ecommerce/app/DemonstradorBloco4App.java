package br.com.ecommerce.app;

import br.com.ecommerce.logistica.PacoteExpresso;
import br.com.ecommerce.util.AuditorMetadadosReflection;
import br.com.ecommerce.util.FilaArmazenamento;

public class DemonstradorBloco4App {

    public static void main(String[] args) {

        System.out.println("=== BLOCO 4 ===");

        System.out.println("\n--- Pool de Strings ---");

        String texto1 = "LOGISTICA";
        String texto2 = "LOGISTICA";
        String texto3 = new String("LOGISTICA");

        System.out.println("texto1 == texto2: " + (texto1 == texto2));
        System.out.println("texto1 == texto3: " + (texto1 == texto3));
        System.out.println("texto1.equals(texto3): "
                + texto1.equals(texto3));

        System.out.println("\n--- Pool de Wrappers ---");

        Integer numero1 = 100;
        Integer numero2 = 100;

        Integer numero3 = 500;
        Integer numero4 = 500;

        System.out.println("100 == 100: " + (numero1 == numero2));
        System.out.println("500 == 500: " + (numero3 == numero4));
        System.out.println("500 equals 500: "
                + numero3.equals(numero4));

        System.out.println("\n--- StringBuilder ---");

        StringBuilder manifesto = new StringBuilder();

        manifesto.append("MANIFESTO DE CARGA\n");

        for (int i = 1; i <= 3; i++) {
            manifesto.append("Pacote ETQ00")
                    .append(i)
                    .append(" - Registrado\n");
        }

        System.out.println(manifesto.toString());

        System.out.println("--- Metodos de Wrappers ---");

        char caractere1 = '8';
        char caractere2 = 'A';

        System.out.println("8 e digito: "
                + Character.isDigit(caractere1));

        System.out.println("A e maiusculo: "
                + Character.isUpperCase(caractere2));

        String numeroTexto = "150";

        int numeroConvertido = Integer.parseInt(numeroTexto);

        System.out.println("Numero convertido: " + numeroConvertido);

        System.out.println("Float.NaN: " + Float.NaN);
        System.out.println("Float.POSITIVE_INFINITY: "
                + Float.POSITIVE_INFINITY);

        System.out.println("\n--- Reflection ---");

        AuditorMetadadosReflection.inspecionarClasse(
                FilaArmazenamento.class);

        AuditorMetadadosReflection.inspecionarClasse(
                PacoteExpresso.class);
    }
}