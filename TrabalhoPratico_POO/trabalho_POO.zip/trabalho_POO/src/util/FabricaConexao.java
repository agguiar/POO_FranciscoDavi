package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaConexao {

    private static final String DRIVER =
            System.getProperty("jdbc.driver", "org.postgresql.Driver");

    private static final String URL =
            System.getProperty("jdbc.url",
                    "jdbc:postgresql://localhost:5432/trabalho_POO");

    private static final String USUARIO =
            System.getProperty("jdbc.usuario", "postgres");

    private static final String SENHA =
            System.getProperty("jdbc.senha", "postgres");

    public static Connection obterConexao()
            throws ClassNotFoundException, SQLException {

        Class.forName(DRIVER);

        return DriverManager.getConnection(
                URL,
                USUARIO,
                SENHA
        );
    }
}