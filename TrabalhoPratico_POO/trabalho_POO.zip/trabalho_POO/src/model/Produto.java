package model;

public class Produto {

    private int id;
    private String codigoBarras;
    private String nome;
    private double preco;
    private int quantidadeEstoque;
    private Categoria categoria;

    public Produto() {
    }

    public Produto(int id, String codigoBarras, String nome, double preco,
                   int quantidadeEstoque, Categoria categoria) {
        this.id = id;
        this.codigoBarras = codigoBarras;
        this.nome = nome;
        this.preco = preco;
        this.quantidadeEstoque = quantidadeEstoque;
        this.categoria = categoria;
    }

    public Produto(String codigoBarras, String nome, double preco,
                   int quantidadeEstoque, Categoria categoria) {
        this.codigoBarras = codigoBarras;
        this.nome = nome;
        this.preco = preco;
        this.quantidadeEstoque = quantidadeEstoque;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigoBarras() {
        return codigoBarras;
    }

    public void setCodigoBarras(String codigoBarras) {
        this.codigoBarras = codigoBarras;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Produto [id=" + id
                + ", codigoBarras=" + codigoBarras
                + ", nome=" + nome
                + ", preco=" + preco
                + ", quantidadeEstoque=" + quantidadeEstoque
                + ", categoria=" + categoria + "]";
    }
}