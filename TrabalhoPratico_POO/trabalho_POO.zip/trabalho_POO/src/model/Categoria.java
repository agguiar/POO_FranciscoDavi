package model;

public class Categoria {

    private int id;
    private String nome;
    private String departamentoLoja;

    public Categoria() {
    }

    public Categoria(int id, String nome, String departamentoLoja) {
        this.id = id;
        this.nome = nome;
        this.departamentoLoja = departamentoLoja;
    }

    public Categoria(String nome, String departamentoLoja) {
        this.nome = nome;
        this.departamentoLoja = departamentoLoja;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDepartamentoLoja() {
        return departamentoLoja;
    }

    public void setDepartamentoLoja(String departamentoLoja) {
        this.departamentoLoja = departamentoLoja;
    }

    @Override
    public String toString() {
        return "Categoria [id=" + id
                + ", nome=" + nome
                + ", departamentoLoja=" + departamentoLoja + "]";
    }
}