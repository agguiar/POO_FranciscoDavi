package controller;

import java.util.Scanner;

import dao.CategoriaDAO;
import dao.ProdutoDAO;
import model.Categoria;
import model.Produto;

public class CtrlProgram {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        CategoriaDAO categoriaDAO = new CategoriaDAO();
        ProdutoDAO produtoDAO = new ProdutoDAO();

        int opcao;

        do {

            System.out.println("\n===== CATÁLOGO E-COMMERCE =====");
            System.out.println("1 - Cadastrar categoria");
            System.out.println("2 - Listar categorias");
            System.out.println("3 - Buscar categoria por ID");
            System.out.println("4 - Atualizar categoria");
            System.out.println("5 - Excluir categoria");
            System.out.println("6 - Cadastrar produto");
            System.out.println("7 - Listar produtos");
            System.out.println("8 - Buscar produto por ID");
            System.out.println("9 - Atualizar produto");
            System.out.println("10 - Excluir produto");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {

            case 1:
                System.out.println("\n--- CADASTRAR CATEGORIA ---");

                System.out.print("Nome da categoria: ");
                String nomeCategoria = scanner.nextLine();

                System.out.print("Departamento da loja: ");
                String departamento = scanner.nextLine();

                Categoria novaCategoria =
                        new Categoria(nomeCategoria, departamento);

                categoriaDAO.salvar(novaCategoria);

                System.out.println(
                        "ID da categoria: " + novaCategoria.getId());

                break;

            case 2:
                System.out.println("\n--- CATEGORIAS ---");

                for (Categoria categoria : categoriaDAO.listarTodos()) {
                    System.out.println(categoria);
                }

                break;

            case 3:
                System.out.println("\n--- BUSCAR CATEGORIA ---");

                System.out.print("ID da categoria: ");
                int idCategoriaBusca = scanner.nextInt();
                scanner.nextLine();

                Categoria categoriaEncontrada =
                        categoriaDAO.buscarPorId(idCategoriaBusca);

                if (categoriaEncontrada != null) {
                    System.out.println(categoriaEncontrada);
                } else {
                    System.out.println("Categoria não encontrada.");
                }

                break;

            case 4:
                System.out.println("\n--- ATUALIZAR CATEGORIA ---");

                System.out.print("ID da categoria: ");
                int idCategoriaAtualizar = scanner.nextInt();
                scanner.nextLine();

                Categoria categoriaAtualizar =
                        categoriaDAO.buscarPorId(idCategoriaAtualizar);

                if (categoriaAtualizar != null) {

                    System.out.print("Novo nome: ");
                    String novoNomeCategoria = scanner.nextLine();

                    System.out.print("Novo departamento: ");
                    String novoDepartamento = scanner.nextLine();

                    categoriaAtualizar.setNome(novoNomeCategoria);
                    categoriaAtualizar.setDepartamentoLoja(novoDepartamento);

                    categoriaDAO.atualizar(categoriaAtualizar);

                } else {
                    System.out.println("Categoria não encontrada.");
                }

                break;

            case 5:
                System.out.println("\n--- EXCLUIR CATEGORIA ---");

                System.out.print("ID da categoria: ");
                int idCategoriaExcluir = scanner.nextInt();
                scanner.nextLine();

                Categoria categoriaExcluir =
                        categoriaDAO.buscarPorId(idCategoriaExcluir);

                if (categoriaExcluir != null) {
                    categoriaDAO.deletar(idCategoriaExcluir);
                } else {
                    System.out.println("Categoria não encontrada.");
                }

                break;

            case 6:
                System.out.println("\n--- CADASTRAR PRODUTO ---");

                System.out.print("Código de barras: ");
                String codigoBarras = scanner.nextLine();

                System.out.print("Nome do produto: ");
                String nomeProduto = scanner.nextLine();

                System.out.print("Preço: ");
                double preco = scanner.nextDouble();

                System.out.print("Quantidade em estoque: ");
                int quantidade = scanner.nextInt();

                System.out.print("ID da categoria: ");
                int idCategoriaProduto = scanner.nextInt();
                scanner.nextLine();

                Categoria categoriaProduto =
                        categoriaDAO.buscarPorId(idCategoriaProduto);

                if (categoriaProduto != null) {

                    Produto novoProduto = new Produto(
                            codigoBarras,
                            nomeProduto,
                            preco,
                            quantidade,
                            categoriaProduto
                    );

                    produtoDAO.salvar(novoProduto);

                    System.out.println(
                            "ID do produto: " + novoProduto.getId());

                } else {
                    System.out.println("Categoria não encontrada.");
                }

                break;

            case 7:
                System.out.println("\n--- PRODUTOS ---");

                for (Produto produto : produtoDAO.listarTodos()) {
                    System.out.println(produto);
                }

                break;

            case 8:
                System.out.println("\n--- BUSCAR PRODUTO ---");

                System.out.print("ID do produto: ");
                int idProdutoBusca = scanner.nextInt();
                scanner.nextLine();

                Produto produtoEncontrado =
                        produtoDAO.buscarPorId(idProdutoBusca);

                if (produtoEncontrado != null) {
                    System.out.println(produtoEncontrado);
                } else {
                    System.out.println("Produto não encontrado.");
                }

                break;

            case 9:
                System.out.println("\n--- ATUALIZAR PRODUTO ---");

                System.out.print("ID do produto: ");
                int idProdutoAtualizar = scanner.nextInt();
                scanner.nextLine();

                Produto produtoAtualizar =
                        produtoDAO.buscarPorId(idProdutoAtualizar);

                if (produtoAtualizar != null) {

                    System.out.print("Novo código de barras: ");
                    String novoCodigo = scanner.nextLine();

                    System.out.print("Novo nome: ");
                    String novoNomeProduto = scanner.nextLine();

                    System.out.print("Novo preço: ");
                    double novoPreco = scanner.nextDouble();

                    System.out.print("Nova quantidade em estoque: ");
                    int novaQuantidade = scanner.nextInt();

                    System.out.print("ID da nova categoria: ");
                    int novaCategoriaId = scanner.nextInt();
                    scanner.nextLine();

                    Categoria categoriaAtualizada =
                            categoriaDAO.buscarPorId(novaCategoriaId);

                    if (categoriaAtualizada != null) {

                        produtoAtualizar.setCodigoBarras(novoCodigo);
                        produtoAtualizar.setNome(novoNomeProduto);
                        produtoAtualizar.setPreco(novoPreco);
                        produtoAtualizar.setQuantidadeEstoque(novaQuantidade);
                        produtoAtualizar.setCategoria(categoriaAtualizada);

                        produtoDAO.atualizar(produtoAtualizar);

                    } else {
                        System.out.println("Categoria não encontrada.");
                    }

                } else {
                    System.out.println("Produto não encontrado.");
                }

                break;

            case 10:
                System.out.println("\n--- EXCLUIR PRODUTO ---");

                System.out.print("ID do produto: ");
                int idProdutoExcluir = scanner.nextInt();
                scanner.nextLine();

                Produto produtoExcluir =
                        produtoDAO.buscarPorId(idProdutoExcluir);

                if (produtoExcluir != null) {
                    produtoDAO.deletar(idProdutoExcluir);
                } else {
                    System.out.println("Produto não encontrado.");
                }

                break;

            case 0:
                System.out.println("\nPrograma encerrado.");
                break;

            default:
                System.out.println("\nOpção inválida.");
            }

        } while (opcao != 0);

        scanner.close();
    }
}