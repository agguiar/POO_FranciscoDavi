package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Categoria;
import model.Produto;
import util.FabricaConexao;

public class ProdutoDAO {

    public void salvar(Produto produto) {

        String sql = "INSERT INTO produto "
                + "(codigo_barras, nome, preco, quantidade_estoque, categoria_id) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, produto.getCodigoBarras());
            stmt.setString(2, produto.getNome());
            stmt.setDouble(3, produto.getPreco());
            stmt.setInt(4, produto.getQuantidadeEstoque());
            stmt.setInt(5, produto.getCategoria().getId());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();

            if (rs.next()) {
                produto.setId(rs.getInt(1));
            }

            System.out.println("Produto salvo com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao salvar produto.");
            e.printStackTrace();
        }
    }

    public Produto buscarPorId(int id) {

        String sql = "SELECT p.id, p.codigo_barras, p.nome, "
                + "p.preco, p.quantidade_estoque, "
                + "c.id AS categoria_id, "
                + "c.nome AS categoria_nome, "
                + "c.departamento_loja "
                + "FROM produto p "
                + "INNER JOIN categoria c ON p.categoria_id = c.id "
                + "WHERE p.id = ?";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                Categoria categoria = new Categoria();

                categoria.setId(rs.getInt("categoria_id"));
                categoria.setNome(rs.getString("categoria_nome"));
                categoria.setDepartamentoLoja(
                        rs.getString("departamento_loja"));

                Produto produto = new Produto();

                produto.setId(rs.getInt("id"));
                produto.setCodigoBarras(
                        rs.getString("codigo_barras"));
                produto.setNome(rs.getString("nome"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setQuantidadeEstoque(
                        rs.getInt("quantidade_estoque"));
                produto.setCategoria(categoria);

                return produto;
            }

        } catch (Exception e) {
            System.out.println("Erro ao buscar produto.");
            e.printStackTrace();
        }

        return null;
    }

    public List<Produto> listarTodos() {

        List<Produto> produtos = new ArrayList<>();

        String sql = "SELECT p.id, p.codigo_barras, p.nome, "
                + "p.preco, p.quantidade_estoque, "
                + "c.id AS categoria_id, "
                + "c.nome AS categoria_nome, "
                + "c.departamento_loja "
                + "FROM produto p "
                + "INNER JOIN categoria c ON p.categoria_id = c.id "
                + "ORDER BY p.id";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Categoria categoria = new Categoria();

                categoria.setId(rs.getInt("categoria_id"));
                categoria.setNome(rs.getString("categoria_nome"));
                categoria.setDepartamentoLoja(
                        rs.getString("departamento_loja"));

                Produto produto = new Produto();

                produto.setId(rs.getInt("id"));
                produto.setCodigoBarras(
                        rs.getString("codigo_barras"));
                produto.setNome(rs.getString("nome"));
                produto.setPreco(rs.getDouble("preco"));
                produto.setQuantidadeEstoque(
                        rs.getInt("quantidade_estoque"));
                produto.setCategoria(categoria);

                produtos.add(produto);
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar produtos.");
            e.printStackTrace();
        }

        return produtos;
    }

    public void atualizar(Produto produto) {

        String sql = "UPDATE produto SET "
                + "codigo_barras = ?, "
                + "nome = ?, "
                + "preco = ?, "
                + "quantidade_estoque = ?, "
                + "categoria_id = ? "
                + "WHERE id = ?";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, produto.getCodigoBarras());
            stmt.setString(2, produto.getNome());
            stmt.setDouble(3, produto.getPreco());
            stmt.setInt(4, produto.getQuantidadeEstoque());
            stmt.setInt(5, produto.getCategoria().getId());
            stmt.setInt(6, produto.getId());

            stmt.executeUpdate();

            System.out.println("Produto atualizado com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao atualizar produto.");
            e.printStackTrace();
        }
    }

    public void deletar(int id) {

        String sql = "DELETE FROM produto WHERE id = ?";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);

            stmt.executeUpdate();

            System.out.println("Produto removido com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao remover produto.");
            e.printStackTrace();
        }
    }
}