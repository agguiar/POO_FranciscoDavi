package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Categoria;
import util.FabricaConexao;

public class CategoriaDAO {

    public void salvar(Categoria categoria) {

        String sql = "INSERT INTO categoria (nome, departamento_loja) VALUES (?, ?)";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, categoria.getNome());
            stmt.setString(2, categoria.getDepartamentoLoja());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();

            if (rs.next()) {
                categoria.setId(rs.getInt(1));
            }

            System.out.println("Categoria salva com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao salvar categoria.");
            e.printStackTrace();
        }
    }

    public Categoria buscarPorId(int id) {

        String sql = "SELECT * FROM categoria WHERE id = ?";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {

                Categoria categoria = new Categoria();

                categoria.setId(rs.getInt("id"));
                categoria.setNome(rs.getString("nome"));
                categoria.setDepartamentoLoja(
                        rs.getString("departamento_loja"));

                return categoria;
            }

        } catch (Exception e) {
            System.out.println("Erro ao buscar categoria.");
            e.printStackTrace();
        }

        return null;
    }

    public List<Categoria> listarTodos() {

        List<Categoria> categorias = new ArrayList<>();

        String sql = "SELECT * FROM categoria ORDER BY id";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Categoria categoria = new Categoria();

                categoria.setId(rs.getInt("id"));
                categoria.setNome(rs.getString("nome"));
                categoria.setDepartamentoLoja(
                        rs.getString("departamento_loja"));

                categorias.add(categoria);
            }

        } catch (Exception e) {
            System.out.println("Erro ao listar categorias.");
            e.printStackTrace();
        }

        return categorias;
    }

    public void atualizar(Categoria categoria) {

        String sql =
                "UPDATE categoria SET nome = ?, departamento_loja = ? WHERE id = ?";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, categoria.getNome());
            stmt.setString(2, categoria.getDepartamentoLoja());
            stmt.setInt(3, categoria.getId());

            stmt.executeUpdate();

            System.out.println("Categoria atualizada com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao atualizar categoria.");
            e.printStackTrace();
        }
    }

    public void deletar(int id) {

        String sql = "DELETE FROM categoria WHERE id = ?";

        try (Connection conexao = FabricaConexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setInt(1, id);

            stmt.executeUpdate();

            System.out.println("Categoria removida com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao remover categoria.");
            e.printStackTrace();
        }
    }
}